# Ansible Collection - jacek.custom_app

Custom collection with App roles and some posix modules
